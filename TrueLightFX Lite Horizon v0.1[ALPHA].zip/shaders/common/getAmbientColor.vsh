vec4 getAmbientColor() {
   float brightness = 1.0 - screenBrightness;
   brightness = 1.0 - brightness * brightness;

   vec4 ambient = texture2DLod(lightmap, vec2(AMBIENT_UV.s, lightUV.t), 0.0);
    vec3 vibrantAmbient = ambient.rgb * (1.1 + clamp(luma(ambient.rgb) * 1.0, 0.0, 0.5));
    ambient.rgb = mix(vibrantAmbient, ambient.rgb, brightness);

   return ambient;
}