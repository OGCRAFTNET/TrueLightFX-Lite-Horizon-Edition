float getFogMix(vec3 worldPos) {
   #ifndef ENABLE_FOG

      return 0.0;

   #endif

   float len = fogShape == 1 ? max(length(worldPos.xz), abs(worldPos.y)) : length(worldPos);

   #if MC_VERSION >= 11700

      #if defined gbuffers_skybasic

         return 0.0;

      #elif defined gbuffers_clouds

         return clamp((length(worldPos.xz) - far * 0.85) / (far * 0.25), 0.0, 1.0);

      #elif defined OVERWORLD

         // Dense underwater distance fog
         if (isEyeInWater == 1) {
            float uwFogEnd = max(fogEnd, 32.0);
            float uwFog = clamp(len / uwFogEnd, 0.0, 1.0);
            return uwFog * uwFog;
         }

         // Smooth atmospheric distance fog blending into the sky/horizon
         float fStart = (fogStart > 0.0 && fogStart < far * 0.95) ? fogStart : far * 0.45;
         float fEnd = (fogEnd > fStart) ? min(fogEnd, far * 0.98) : far * 0.98;
         float distFog = clamp((len - fStart) / (fEnd - fStart), 0.0, 1.0);
         distFog = distFog * distFog;

         float x = worldTime * NORMALIZE_TIME;

         x = clamp(25.0*(x < MIDNIGHT ? SUNSET - x : x - SUNRISE) + 0.3,
                  OVERWORLD_FOG_MIN,
                  OVERWORLD_FOG_MAX);

         float nightFogDensity = 1.0 - clamp(abs((worldTime * NORMALIZE_TIME) - MIDNIGHT) * 10.0, 0.0, 1.0);
         x *= mix(1.0, 0.6, nightFogDensity); 

         x = min(x, 1.0 - rainStrength);
         x = max(x, 0.05);

         vec3 rayDir = normalize(worldPos);
         float b = 0.025; 
         float c = 0.015 * x; 
         
         float t = b * rayDir.y;
         float num_over_den = (abs(t) > 0.0001) ? ((1.0 - exp(-len * t)) / t) : len;
         float fogAmount = c * exp(-(cameraPosition.y - 64.0) * b) * num_over_den;
         float heightFog = 1.0 - exp(-max(fogAmount, 0.0));

         return clamp(max(distFog, heightFog), 0.0, 1.0);

      #else

         return smoothstep(0.0, 1.0, rescale(len, 0.5 * far, far));

      #endif

   #else

      gl_FogFragCoord = len;

      return (isEyeInWater > 0) ? 1.0 - exp(-gl_FogFragCoord * gl_Fog.density)
                                 : clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0);

   #endif
}