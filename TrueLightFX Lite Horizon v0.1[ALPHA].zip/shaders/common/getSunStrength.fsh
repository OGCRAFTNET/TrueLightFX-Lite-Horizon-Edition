#include "/common/getShadowDistortion.glsl"

float getSunStrength() {
   if (diffuse <= 0.0) return 0.0;

   // Surface normal in player space
   vec3 n = length(normal) > 0.1 ? normalize(normal) : vec3(0.0, 1.0, 0.0);
   // Light direction in player space (invariant to camera rotation)
   vec3 lDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
   
   float NdotL = clamp(dot(n, lDir), 0.0, 1.0);

   // Dynamic slope-scaled normal bias offset
   // Offsets sample slightly along surface normal to eliminate self-intersection acne
   float normalBiasOffset = 0.035 + 0.050 * (1.0 - NdotL);

#if SHADOW_PIXEL > 0
   // Tangent-plane pixel snapping (if retro mode enabled)
   vec3 absN = abs(n);
   vec3 world = worldPos + cameraPosition;
   vec3 snapped = world;
   float pixelScale = float(SHADOW_PIXEL);

   if (absN.y >= absN.x && absN.y >= absN.z) {
      snapped.xz = (floor(world.xz * pixelScale) + 0.5) / pixelScale;
   } else if (absN.x >= absN.z) {
      snapped.yz = (floor(world.yz * pixelScale) + 0.5) / pixelScale;
   } else {
      snapped.xy = (floor(world.xy * pixelScale) + 0.5) / pixelScale;
   }

   vec3 diff = snapped - world;
   float lightBias = max(-dot(diff, lDir), 0.0);
   vec3 pos = snapped - cameraPosition + n * normalBiasOffset + lDir * (lightBias + 0.015);
#else
   // Smooth continuous world-position for realistic soft shadows
   vec3 pos = worldPos + n * normalBiasOffset;
#endif

   float posDistance = squaredLength(pos);
   if (posDistance >= SHADOW_MAX_DIST_SQUARED) {
      return diffuse;
   }

   vec4 shadowView = shadowModelView * vec4(pos, 1.0);
   vec4 shadowClip = shadowProjection * shadowView;

   // Distortion scale compensation
   vec2 absClip = abs(shadowClip.xy);
   vec2 distortDiv = 0.8 * absClip + 0.2;
   float distortScale = max(distortDiv.x, distortDiv.y) / 0.2;

   shadowClip.xyz = getShadowDistortion(shadowClip.xyz);

   vec3 shadowUV = nvec3(shadowClip) * 0.5 + 0.5;

   if (shadowUV.z < 1.0 &&
       shadowUV.s > 0.0 && shadowUV.s < 1.0 &&
       shadowUV.t > 0.0 && shadowUV.t < 1.0)
   {
      vec2 edgeDist = min(shadowUV.st, vec2(1.0) - shadowUV.st);
      float edgeFade = clamp(min(edgeDist.x, edgeDist.y) * 15.0, 0.0, 1.0);
      float shadowFade = clamp(1.0 - posDistance * INV_SHADOW_MAX_DIST_SQUARED, 0.0, 1.0) * edgeFade;

      if (shadowFade <= 0.0) return diffuse;

      // Dynamic slope-scaled depth bias (matches user specification)
      // Eliminates self-shadowing acne at grazing angles while maintaining contact sharpness
      float bias = max(0.0035 * (1.0 - NdotL), 0.0006) * distortScale;

      float res = float(shadowMapResolution);
      vec2 texelSize = vec2(1.0 / res);

#if SHADOW_PIXEL > 0
      // 4-tap soft PCF box filter for pixel mode to eliminate acne speckles
      float shadowFactor = 0.0;
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.5, -0.5) * texelSize).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.5, -0.5) * texelSize).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.5,  0.5) * texelSize).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.5,  0.5) * texelSize).x + bias, shadowUV.z);
      shadowFactor *= 0.25;

      return diffuse * (1.0 - shadowFade * shadowFactor);
#else
      // 12-tap Poisson disk PCF filter with uniform isotropic distribution
      // Completely eliminates moiré noise, acne, and produces realistic soft shadow penumbra
      float shadowFactor = 0.0;
      float filterRadius = 1.5;

      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.326, -0.406) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.840, -0.074) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.696,  0.457) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.203,  0.621) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.962, -0.195) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.473, -0.480) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.519,  0.767) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.185, -0.893) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.507,  0.064) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2( 0.896,  0.412) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.322, -0.933) * texelSize * filterRadius).x + bias, shadowUV.z);
      shadowFactor += step(texture2D(shadowtex1, shadowUV.st + vec2(-0.792, -0.598) * texelSize * filterRadius).x + bias, shadowUV.z);

      shadowFactor *= (1.0 / 12.0);

      return diffuse * (1.0 - shadowFade * shadowFactor);
#endif
   }

   return diffuse;
}
