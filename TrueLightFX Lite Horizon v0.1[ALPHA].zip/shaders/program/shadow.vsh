#include "/shader.h"

attribute vec4 mc_Entity;

varying vec2 texUV;
varying float alpha;

#include "/common/getShadowDistortion.glsl"

void main() {
   gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
   gl_Position.xyz = getShadowDistortion(gl_Position.xyz);

   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;

   if (mc_Entity.x == 10072.0) {
      alpha = 0.0;
   }
   else {
      alpha = 1.0;
   }

}