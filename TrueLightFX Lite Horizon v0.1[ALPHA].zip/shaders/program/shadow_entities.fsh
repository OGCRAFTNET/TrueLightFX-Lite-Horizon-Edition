uniform sampler2D texture;

varying vec2 texUV;

void main() {
   // Entities (mobs, players) are solid 3D geometry and always cast full sunlight shadows
   gl_FragData[0] = vec4(1.0);
}
