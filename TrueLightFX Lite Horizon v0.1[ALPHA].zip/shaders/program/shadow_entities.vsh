#include "/shader.h"

varying vec2 texUV;

#include "/common/getShadowDistortion.glsl"

void main() {
   gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
   gl_Position.xyz = getShadowDistortion(gl_Position.xyz);
   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
}
