uniform sampler2D texture;

varying vec2 texUV;
varying float alpha;

#include "/common/math.glsl"

void main() {
   if (alpha < 0.5) {
      discard;
   }

   vec4 albedo = texture2D(texture, texUV);

   if (albedo.a < 0.1) {
      discard;
   }

   gl_FragData[0] = albedo;
}