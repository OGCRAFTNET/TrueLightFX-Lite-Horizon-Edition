#version 120

uniform mat4 gbufferModelViewInverse;
uniform float near, far;
uniform float fogStart, fogEnd;

varying float fogMix;
varying vec2 texUV;
varying vec2 lightUV;
varying vec3 worldPos;
varying vec4 color;

vec3 getWorldPosition() {
   return mat3(gbufferModelViewInverse) * (gl_ModelViewMatrix * gl_Vertex).xyz + gbufferModelViewInverse[3].xyz;
}

void main() {
   gl_Position = ftransform();
   color = gl_Color;
   texUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
   lightUV = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;

   worldPos = getWorldPosition();
   float len = length(worldPos);
   fogMix = clamp((len - far) * (near * 0.01), 0.0, 1.0);
}
