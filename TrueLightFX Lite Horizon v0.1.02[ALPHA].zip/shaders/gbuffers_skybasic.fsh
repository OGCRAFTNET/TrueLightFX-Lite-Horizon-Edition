#version 120
/* DRAWBUFFERS:0 */

uniform float viewHeight;
uniform float viewWidth;
uniform mat4 gbufferModelView;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform int isEyeInWater;

varying vec4 starColor;

void main() {
    vec3 color;

    if (starColor.a > 0.9) {
        color = starColor.rgb;
    } else {
        vec2 uv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
        vec4 clipPos = vec4(uv * 2.0 - 1.0, 1.0, 1.0);
        vec4 viewPos = gbufferProjectionInverse * clipPos;
        vec3 screenPos = normalize(viewPos.xyz / viewPos.w);
        float upDot = dot(screenPos, normalize(gbufferModelView[1].xyz));

        vec3 zenithColor = skyColor * vec3(0.55, 0.70, 1.25); 
        vec3 midColor    = skyColor * vec3(0.92, 0.97, 1.10); 
        vec3 horizonColor = mix(skyColor, fogColor, 0.6) * vec3(1.05, 1.05, 1.02); 

        vec3 vibrantSky;
        if (upDot > 0.3) {
            float t = smoothstep(0.3, 0.9, upDot);
            vibrantSky = mix(midColor, zenithColor, t);
        } else {
            float t = smoothstep(0.0, 0.3, upDot);
            vibrantSky = mix(horizonColor, midColor, t);
        }

        vec3 finalFogColor = mix(fogColor, vec3(0.02, 0.35, 0.55), float(isEyeInWater == 1) * 0.75);
        
        float horizonFog = pow(clamp(1.0 - max(upDot, 0.0), 0.0, 1.0), 4.5);
        color = mix(vibrantSky, finalFogColor, horizonFog * 0.85);
    }

    gl_FragData[0] = vec4(color, 1.0);
}
