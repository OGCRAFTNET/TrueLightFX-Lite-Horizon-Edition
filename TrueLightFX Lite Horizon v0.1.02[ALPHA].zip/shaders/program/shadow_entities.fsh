uniform sampler2D texture;

varying vec2 texUV;

void main() {
   gl_FragData[0] = vec4(1.0);
}
