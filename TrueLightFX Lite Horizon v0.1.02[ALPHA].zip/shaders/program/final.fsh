#define final

#include "/shader.h"

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform int worldTime;
uniform float frameTimeCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform float rainStrength;
uniform float near;
uniform float far;
uniform int isEyeInWater;

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.fsh"
#include "/common/getReflectionColor.fsh"

float InterleavedGradientNoise(vec2 uv) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(uv, magic.xy)));
}

#ifdef FXAA
float fxaaLuma(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

vec3 applyFXAA(vec2 uv) {
    vec2 pixelSize = vec2(1.0 / viewWidth, 1.0 / viewHeight);
    
    const float qSteps[12] = float[12](1.0, 1.0, 1.0, 1.0, 1.0, 1.5, 2.0, 2.0, 2.0, 2.0, 4.0, 8.0);
    int maxIters = 12;

    vec3 centerColor = texture2D(colortex1, uv).rgb;
    float lCenter = fxaaLuma(centerColor);
    
    float lD = fxaaLuma(texture2D(colortex1, uv + vec2(0.0, -pixelSize.y)).rgb);
    float lU = fxaaLuma(texture2D(colortex1, uv + vec2(0.0,  pixelSize.y)).rgb);
    float lL = fxaaLuma(texture2D(colortex1, uv + vec2(-pixelSize.x, 0.0)).rgb);
    float lR = fxaaLuma(texture2D(colortex1, uv + vec2( pixelSize.x, 0.0)).rgb);

    float lMin = min(lCenter, min(min(lD, lU), min(lL, lR)));
    float lMax = max(lCenter, max(max(lD, lU), max(lL, lR)));
    float lRange = lMax - lMin;

    if (lRange <= max(FXAA_EDGE_THRESHOLD_MIN, lMax * FXAA_EDGE_THRESHOLD)) {
        return centerColor;
    }

    float lDL = fxaaLuma(texture2D(colortex1, uv + vec2(-pixelSize.x, -pixelSize.y)).rgb);
    float lUR = fxaaLuma(texture2D(colortex1, uv + vec2( pixelSize.x,  pixelSize.y)).rgb);
    float lUL = fxaaLuma(texture2D(colortex1, uv + vec2(-pixelSize.x,  pixelSize.y)).rgb);
    float lDR = fxaaLuma(texture2D(colortex1, uv + vec2( pixelSize.x, -pixelSize.y)).rgb);

    float lDU = lD + lU;
    float lLR = lL + lR;

    float lLeftCorners = lDL + lUL;
    float lDownCorners = lDL + lDR;
    float lRightCorners = lDR + lUR;
    float lUpCorners = lUR + lUL;

    float eHorz = abs(-2.0 * lL + lLeftCorners) + abs(-2.0 * lCenter + lDU) * 2.0 + abs(-2.0 * lR + lRightCorners);
    float eVert = abs(-2.0 * lU + lUpCorners) + abs(-2.0 * lCenter + lLR) * 2.0 + abs(-2.0 * lD + lDownCorners);

    bool isH = (eHorz >= eVert);
    
    float lAdj1 = isH ? lD : lL;
    float lAdj2 = isH ? lU : lR;
    float g1 = lAdj1 - lCenter;
    float g2 = lAdj2 - lCenter;
    
    bool is1Steep = abs(g1) >= abs(g2);
    float gScaled = 0.25 * max(abs(g1), abs(g2));

    float stepLen = isH ? pixelSize.y : pixelSize.x;
    float lLocalAvg = 0.0;
    
    if (is1Steep) {
        stepLen = -stepLen;
        lLocalAvg = 0.5 * (lAdj1 + lCenter);
    } else {
        lLocalAvg = 0.5 * (lAdj2 + lCenter);
    }

    vec2 pUv = uv;
    if (isH) pUv.y += stepLen * 0.5;
    else     pUv.x += stepLen * 0.5;

    vec2 dirOff = isH ? vec2(pixelSize.x, 0.0) : vec2(0.0, pixelSize.y);
    vec2 p1 = pUv - dirOff;
    vec2 p2 = pUv + dirOff;

    float lEnd1 = fxaaLuma(texture2D(colortex1, p1).rgb) - lLocalAvg;
    float lEnd2 = fxaaLuma(texture2D(colortex1, p2).rgb) - lLocalAvg;

    bool reach1 = abs(lEnd1) >= gScaled;
    bool reach2 = abs(lEnd2) >= gScaled;

    if (!reach1) p1 -= dirOff;
    if (!reach2) p2 += dirOff;

    if (!(reach1 && reach2)) {
        for (int i = 2; i < maxIters; i++) {
            if (!reach1) {
                lEnd1 = fxaaLuma(texture2D(colortex1, p1).rgb) - lLocalAvg;
                reach1 = abs(lEnd1) >= gScaled;
            }
            if (!reach2) {
                lEnd2 = fxaaLuma(texture2D(colortex1, p2).rgb) - lLocalAvg;
                reach2 = abs(lEnd2) >= gScaled;
            }
            
            if (!reach1) p1 -= dirOff * qSteps[i];
            if (!reach2) p2 += dirOff * qSteps[i];

            if (reach1 && reach2) break;
        }
    }

    float d1 = isH ? (uv.x - p1.x) : (uv.y - p1.y);
    float d2 = isH ? (p2.x - uv.x) : (p2.y - uv.y);

    bool bDir1 = d1 < d2;
    float dFinal = min(d1, d2);
    float eThick = d1 + d2;
    float subOff = -dFinal / eThick + 0.5;

    bool lCenterSmall = lCenter < lLocalAvg;
    bool vMatch = ((bDir1 ? lEnd1 : lEnd2) < 0.0) != lCenterSmall;

    float fOffset = vMatch ? subOff : 0.0;

    float lAvg = (1.0/12.0) * (2.0 * (lDU + lLR) + lLeftCorners + lRightCorners);
    float sOff1 = clamp(abs(lAvg - lCenter) / lRange, 0.0, 1.0);
    float sOff2 = (-2.0 * sOff1 + 3.0) * sOff1 * sOff1;
    float sOffFin = sOff2 * sOff2 * 0.75;

    fOffset = max(fOffset, sOffFin);

    vec2 fUv = uv;
    if (isH) fUv.y += fOffset * stepLen;
    else     fUv.x += fOffset * stepLen;

    return texture2D(colortex1, fUv).rgb;
}
#endif

void main() {
   vec4 color = texture2D(colortex1, texUV);
   vec4 info  = texture2D(colortex7, texUV);

   if (info.x > 0.99) {

      vec3 prenormal = texture2D(colortex6, texUV).xyz*2.0 - 1.0;

      #if WATER_WAVE_SIZE > 0

         if (info.y > 0.99 && abs(prenormal.y) > 0.8) {
            prenormal.xz *= 0.01 * WATER_WAVE_SIZE;
         }

      #endif

      #if REFLECTIONS > 0
         float depth          = texture2D(depthtex0, texUV).x;
         vec3 normal          = world2screen(prenormal);
         vec3 fragPos         = uv2screen(texUV, depth);
         vec4 reflectionColor = getReflectionColor(depth, normal, fragPos);
         float cosTheta       = clamp(dot(normal, -normalize(fragPos)), 0.0, 1.0);

         float fresnel;
         if (isEyeInWater == 1) {
            fresnel = 0.7 + 0.3 * pow(1.0 - cosTheta, 3.0);
         } else {
            fresnel = 0.45 + 0.55 * pow(1.0 - cosTheta, 5.0);
         }

         color.rgb = mix(
            color.rgb,
            reflectionColor.rgb,
            clamp(reflectionColor.a * fresnel * float(REFLECTIONS) * 0.1, 0.0, 1.0)
         );
      #endif
   }

   #ifdef WATER_CAUSTICS
      if (isEyeInWater == 1) {
         float zDepth = texture2D(depthtex0, texUV).r;
         if (zDepth < 1.0) {
            vec3 viewPos = uv2screen(texUV, zDepth);
            vec3 worldVector = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
            vec3 worldP = cameraPosition + worldVector;

            float cx = worldP.x * 2.0;
            float cz = worldP.z * 2.0;
            float ct = frameTimeCounter * 3.0;
            
            float causticStr = sin(cx + ct) * sin(cz - ct) * 0.5 + 0.5;
            causticStr *= sin(cx * 0.5 - ct * 1.3) * sin(cz * 0.5 + ct * 1.3) * 0.5 + 0.5;
            
            color.rgb += vec3(0.05, 0.4, 0.6) * (causticStr * 0.25);
         }
      }
   #endif

   #ifdef SUN_RAYS
      vec3 worldSun = mat3(gbufferModelViewInverse) * sunPosition;
      bool isDay = (worldSun.y > -15.0);
      vec3 lightPos = isDay ? sunPosition : moonPosition;
      vec4 screenLight = gbufferProjection * vec4(lightPos, 1.0);

      if (screenLight.w > 0.0) {
         vec2 lightUV = (screenLight.xy / screenLight.w) * 0.5 + 0.5;

         float offX = max(0.0, max(-lightUV.x, lightUV.x - 1.0));
         float offY = max(0.0, max(-lightUV.y, lightUV.y - 1.0));
         float screenFade = clamp(1.0 - (offX + offY) * 2.0, 0.0, 1.0);

         if (screenFade > 0.01) {
            #ifdef TAA
               float dither = InterleavedGradientNoise(gl_FragCoord.xy + frameTimeCounter * 64.0);
            #else
               float dither = InterleavedGradientNoise(gl_FragCoord.xy);
            #endif

            const int SAMPLES = 16;
            vec2 deltaUV = (lightUV - texUV) / float(SAMPLES);
            vec2 curUV = texUV + deltaUV * dither;

            float accum = 0.0;
            float decay = 1.0;
            const float decayStep = 0.93;
            const float sampleWeight = 0.12;

            for (int i = 0; i < SAMPLES; i++) {
               if (curUV.x < 0.0 || curUV.x > 1.0 || curUV.y < 0.0 || curUV.y > 1.0) break;

               float d = texture2D(depthtex0, curUV).r;
               if (d > 0.9995) {
                  float distToSource = length(curUV - lightUV);
                  float sunDisk = smoothstep(0.22, 0.03, distToSource);
                  accum += sunDisk * decay * sampleWeight;
               }

               curUV += deltaUV;
               decay *= decayStep;
            }

            vec3 rayColor;
            if (isDay) {
               float sunset = clamp(1.0 - worldSun.y / 60.0, 0.0, 1.0);
               rayColor = mix(vec3(1.0, 0.92, 0.75), vec3(1.0, 0.45, 0.15), sunset);
            } else {
               rayColor = vec3(0.40, 0.60, 0.95) * 0.5;
            }

            rayColor *= (1.0 - rainStrength * 0.85);

            float distToSun = length(lightUV - texUV);
            float radialFalloff = exp(-distToSun * 3.5);

            float sceneDepth = texture2D(depthtex0, texUV).r;
            float skyAtten = (sceneDepth > 0.9995) ? 0.35 : 1.0;

            float intensity = float(SUN_RAYS_INTENSITY) * 0.12;
            vec3 godrays = accum * rayColor * radialFalloff * intensity * screenFade * skyAtten;

            color.rgb += godrays;
         }
      }
   #endif



   #ifdef FXAA
      vec3 fxaaOut = applyFXAA(texUV);
      vec3 sceneDiff = color.rgb - texture2D(colortex1, texUV).rgb;
      color.rgb = mix(color.rgb, fxaaOut + sceneDiff, FXAA_STRENGTH);
   #endif

   #ifdef VIBRANCE
      float vibrance = VIBRANCE;
      float l = luma(color.rgb);
      color.rgb = mix(vec3(l), color.rgb, 1.0 + vibrance);
   #endif

    #ifdef BLOOM
       vec2 res = 2.0 / vec2(viewWidth, viewHeight);
       vec3 bloom = texture2D(colortex1, texUV + vec2(-2.0*res.x, 0.0)).rgb;
       bloom += texture2D(colortex1, texUV + vec2(-1.0*res.x, 0.0)).rgb;
       bloom += texture2D(colortex1, texUV + vec2( 1.0*res.x, 0.0)).rgb;
       bloom += texture2D(colortex1, texUV + vec2( 2.0*res.x, 0.0)).rgb;
       bloom += texture2D(colortex1, texUV + vec2( 0.0, -2.0*res.y)).rgb;
       bloom += texture2D(colortex1, texUV + vec2( 0.0, -1.0*res.y)).rgb;
       bloom += texture2D(colortex1, texUV + vec2( 0.0,  0.0      )).rgb;
       bloom += texture2D(colortex1, texUV + vec2( 0.0,  1.0*res.y)).rgb;
       bloom += texture2D(colortex1, texUV + vec2( 0.0,  2.0*res.y)).rgb;
       
       bloom *= 0.111;
       
       bloom = (bloom * bloom * bloom) * BLOOM_STRENGTH;
       color.rgb += bloom;
    #endif

    float preLuma = luma(color.rgb);
    color.rgb = mix(vec3(preLuma), color.rgb, 1.25);

    color.rgb = color.rgb / pow(color.rgb * color.rgb * color.rgb + 1.0, vec3(0.333));
    color.rgb = pow(color.rgb, vec3(1.1));

   color.rgb = clamp(color.rgb, 0.0, 1.0);

   gl_FragData[0] = color;
}