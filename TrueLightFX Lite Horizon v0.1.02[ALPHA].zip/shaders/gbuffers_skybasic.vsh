#version 120

uniform mat4 gbufferModelView;
varying vec4 starColor;

float random(vec2 pos) {
    return fract(sin(dot(pos, vec2(18.9898, 28.633))) * 4378.5453);
}

void main() {
    gl_Position = ftransform();

    bool isStar = (gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0 && gl_Color.r < 0.51);
    starColor = vec4(
        random(gl_Vertex.xy) * gl_Color.rgb * 2.0,
        float(isStar)
    );
}
