#include "/common/getShadowDistortion.glsl"

float getSunStrength() {
   #if SHADOW_PIXEL > 0
      vec3 pos = worldPos + cameraPosition;
      pos = pos * float(SHADOW_PIXEL);
      pos = floor(pos + 0.01) + 0.5;
      pos = pos / float(SHADOW_PIXEL) - cameraPosition;
   #else
      vec3 pos = worldPos;
   #endif

   float posDistance = squaredLength(pos);
   if (posDistance >= SHADOW_MAX_DIST_SQUARED || diffuse <= 0.0) {
      return diffuse;
   }

   vec4 shadowView = shadowModelView * vec4(pos, 1.0);
   vec4 shadowClip = shadowProjection * shadowView;

   vec2 absClip = abs(shadowClip.xy);
   vec2 distortDiv = 0.8 * absClip + 0.2;
   float distortScale = max(distortDiv.x, distortDiv.y) / 0.2;

   shadowClip.xyz = getShadowDistortion(shadowClip.xyz);

   vec3 shadowUV = nvec3(shadowClip) * 0.5 + 0.5;

   if (shadowUV.z < 1.0 &&
       shadowUV.s > 0.0 && shadowUV.s < 1.0 &&
       shadowUV.t > 0.0 && shadowUV.t < 1.0)
   {
      float shadowFade = 1.0 - posDistance * INV_SHADOW_MAX_DIST_SQUARED;
      float shadowDepth = texture2D(shadowtex1, shadowUV.st).x;
      float bias = 0.001 * distortScale;
      float inShadow = step(shadowDepth + bias, shadowUV.z);

      return diffuse * (1.0 - shadowFade * inShadow);
   }

   return diffuse;
}
